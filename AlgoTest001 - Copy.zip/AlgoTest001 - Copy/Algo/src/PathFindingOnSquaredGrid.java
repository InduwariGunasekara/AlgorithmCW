
import java.awt.Color;
import java.util.*;

/**
 * ***********************************************************************
 * Author: Dr E Kapetanios Last update: 22-02-2017
 *
 ************************************************************************
 */
public class PathFindingOnSquaredGrid {

    // given an N-by-N matrix of open cells, return an N-by-N matrix
    // of cells reachable from the top
    public static boolean[][] flow(boolean[][] open) {
        int N = open.length;

        boolean[][] full = new boolean[N][N];
        for (int j = 0; j < N; j++) {
            flow(open, full, 0, j);
        }

        return full;
    }

    // determine set of open/blocked cells using depth first search
    public static void flow(boolean[][] open, boolean[][] full, int i, int j) {
        int N = open.length;

        // base cases
        if (i < 0 || i >= N) {
            return;    // invalid row
        }
        if (j < 0 || j >= N) {
            return;    // invalid column
        }
        if (!open[i][j]) {
            return;        // not an open cell
        }
        if (full[i][j]) {
            return;         // already marked as open
        }
        full[i][j] = true;

        flow(open, full, i + 1, j);   // down
        flow(open, full, i, j + 1);   // right
        flow(open, full, i, j - 1);   // left
        flow(open, full, i - 1, j);   // up
    }

    // does the system percolate?
    public static boolean percolates(boolean[][] open) {
        int N = open.length;

        boolean[][] full = flow(open);
        for (int j = 0; j < N; j++) {
            if (full[N - 1][j]) {
                return true;
            }
        }

        return false;
    }

    // does the system percolate vertically in a direct way?
    public static boolean percolatesDirect(boolean[][] open) {
        int N = open.length;

        boolean[][] full = flow(open);
        int directPerc = 0;
        for (int j = 0; j < N; j++) {
            if (full[N - 1][j]) {
                // StdOut.println("Hello");
                directPerc = 1;
                int rowabove = N - 2;
                for (int i = rowabove; i >= 0; i--) {
                    if (full[i][j]) {
                        // StdOut.println("i: " + i + " j: " + j + " " + full[i][j]);
                        directPerc++;
                    } else {
                        break;
                    }
                }
            }
        }

        // StdOut.println("Direct Percolation is: " + directPerc);
        if (directPerc == N) {
            return true;
        } else {
            return false;
        }
    }

    //Find the Path
//    public static void  pathFind(boolean[][] a, boolean which, int x1, int y1, int x2, int y2, String method){
//        int [][] openList =new int [100][100];
//        int [][] closedList =new int [100][100];
//        closedList.add(x1,y1);
//        for(int i=x1-1; i<=x1+1; i++){
//            for(int j=y1-1; j<=y1+1; j++){
//                if(!(a[i][j]==false) || closedList.contains(i,j)){
//                    distance(i,j,x2,y2,method);
//                }
//            }
//            
//        }
//    }
    //Find distance
//    public static int distance(int x1,int y1, int x2, int y2, String method){       
//            if (method.equalsIgnoreCase("M")){
//                int distance=Math.abs(x1-x2) - Math.abs(y1-y2);
//                return  distance;
//            } 
//            else if(method.equalsIgnoreCase("E")) {
//                int distance=(int)Math.pow((int) Math.pow(x1-x2,2)+(int)Math.pow(y1-y2,2),1/2);
//            }
//            else if(method.equalsIgnoreCase("C")) {
//                int distance=max(Math.abs(x1-x2) , Math.abs(y1-y2));
//            }
//            else{
//                System.out.println("Enter correct letter for a method >");
//                System.out.println("For the Manhatten method, Enter '/M'/ ");
//                System.out.println("For the Euclidean method, Enter '/E'/ ");
//                System.out.println("For the Chebyshev method, Enter '/C'/ ");
//            }
//         return 0;   
//    }
//    
    // draw the N-by-N boolean matrix to standard draw
    public static void show(boolean[][] a, boolean which) {
        int N = a.length;
        StdDraw.setXscale(-1, N);
        StdDraw.setYscale(-1, N);
        StdDraw.setPenColor(StdDraw.BLACK);
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (a[i][j] == which) {
                    StdDraw.square(j, N - i - 1, .5);
                } else {
                    StdDraw.filledSquare(j, N - i - 1, .5);
                }
            }
        }
    }

    // draw the N-by-N boolean matrix to standard draw, including the points A (x1, y1) and B (x2,y2) to be marked by a circle
    public static void show(boolean[][] a, boolean which, int x1, int y1, int x2, int y2) {
        int N = a.length;
        StdDraw.setXscale(-1, N);;
        StdDraw.setYscale(-1, N);
        StdDraw.setPenColor(StdDraw.BLACK);
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (a[i][j] == which) {
                    if ((i == x1 && j == y1) || (i == x2 && j == y2)) {
                        StdDraw.circle(j, N - i - 1, .5);
                    } else {
                        StdDraw.square(j, N - i - 1, .5);
                    }
                } else {
                    StdDraw.filledSquare(j, N - i - 1, .5);
                }
            }
        }
    }

    // return a random N-by-N boolean matrix, where each entry is
    // true with probability p
    public static boolean[][] random(int N, double p) {
        boolean[][] a = new boolean[N][N];
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                a[i][j] = StdRandom.bernoulli(p);
            }
        }
        return a;
    }

    // test client
    public static void main(String[] args) {
        // boolean[][] open = StdArrayIO.readBoolean2D();

        // The following will generate a 10x10 squared grid with relatively few obstacles in it
        // The lower the second parameter, the more obstacles (black cells) are generated
        boolean[][] randomlyGenMatrix = random(10, 0.7);

        StdArrayIO.print(randomlyGenMatrix);
        show(randomlyGenMatrix, true);

        System.out.println();
        System.out.println("The system percolates: " + percolates(randomlyGenMatrix));

        System.out.println();
        System.out.println("The system percolates directly: " + percolatesDirect(randomlyGenMatrix));
        System.out.println();

        // Reading the coordinates for points A and B on the input squared grid.
        // THIS IS AN EXAMPLE ONLY ON HOW TO USE THE JAVA INTERNAL WATCH
        // Start the clock ticking in order to capture the time being spent on inputting the coordinates
        // You should position this command accordingly in order to perform the algorithmic analysis
        Stopwatch timerFlow = new Stopwatch();

        Scanner in = new Scanner(System.in);
        System.out.println("Enter i for A > ");
        int Ai = in.nextInt();

        System.out.println("Enter j for A > ");
        int Aj = in.nextInt();

        System.out.println("Enter i for B > ");
        int Bi = in.nextInt();

        System.out.println("Enter j for B > ");
        int Bj = in.nextInt();

        System.out.println("Enter calculating method > ");
        System.out.println("For the Manhatten method, Enter M ");
        System.out.println("For the Euclidean method, Enter E ");
        System.out.println("For the Chebyshev method, Enter C ");
        String method = in.next();

        // THIS IS AN EXAMPLE ONLY ON HOW TO USE THE JAVA INTERNAL WATCH
        // Stop the clock ticking in order to capture the time being spent on inputting the coordinates
        // You should position this command accordingly in order to perform the algorithmic analysis
        StdOut.println("Elapsed time = " + timerFlow.elapsedTime());

        // System.out.println("Coordinates for A: [" + Ai + "," + Aj + "]");
        // System.out.println("Coordinates for B: [" + Bi + "," + Bj + "]");
        show(randomlyGenMatrix, true, Ai, Aj, Bi, Bj);
        //distance(Ai,Aj,Bi,Bj,method);
        // pathFind(randomlyGenMatrix, true, Ai, Aj, Bi, Bj,method);

        Cell[][] grid = createCell(randomlyGenMatrix, Ai, Aj, Bi, Bj,method);
        //    System.out.println("hhhh");
        aStar(grid, Ai, Aj, Bi, Bj);
    }

    private static Cell[][] createCell(boolean[][] randomlyGenMatrix, int Ai, int Aj, int Bi, int Bj, String method) {
        int N = randomlyGenMatrix.length;
        Cell[][] grid = new Cell[N][N];
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                Cell cell = new Cell();
                cell.i = i;
                cell.j = j;
                if(method.equalsIgnoreCase("M")){
                cell.hcost = Math.abs(i - Bi) + Math.abs(j - Bj);
                }
                else if(method.equalsIgnoreCase("E")){
                cell.hcost= (int)Math.pow((int) Math.pow(i-Bi,2)+(int)Math.pow(j-Bj,2),1/2);
                }
                else if(method.equalsIgnoreCase("C")){
                cell.hcost=Math.max(Math.abs(i - Bi),Math.abs(j - Bj));
                }else{
                System.out.println("Enter correct letter for a method >");
                System.out.println("For the Manhatten method, Enter '/M'/ ");
                System.out.println("For the Euclidean method, Enter '/E'/ ");
                System.out.println("For the Chebyshev method, Enter '/C'/ ");
            }
                
                
                cell.blocked = randomlyGenMatrix[i][j];
                grid[i][j] = cell;
            }
        }
        return grid;

    }

    private static void aStar(Cell[][] grid, int Ai, int Aj, int Bi, int Bj) {
        int N = grid.length;
        Queue<Cell> openList = new PriorityQueue<>(new Comparator<Cell>() {

            @Override
            public int compare(Cell o1, Cell o2) {
                return o1.getFCost() < o2.getFCost() ? -1 : o1.getFCost() > o2.getFCost() ? 1 : 0;
            }
        });
        List<Cell> closedList = new LinkedList<Cell>();
        openList.add(grid[Ai][Aj]);

        while (!openList.isEmpty()) {
            Cell index = openList.poll();
            if (index.i == Bi && index.j == Bj) {
                break;
            }
            List<Cell> neighbours = neighbours(index, grid);
            for (Cell neighbour : neighbours) {
                if (!closedList.contains(neighbour)) {
                    if (!openList.contains(neighbour)) {
                        neighbour.gcost = index.gcost + 1;
                        neighbour.parent = index;
                        openList.add(neighbour);
                    } else {
                        int gCost = index.gcost + 1;
                        if (neighbour.gcost > gCost) {
                            neighbour.gcost = gCost;
                            neighbour.parent = index;
                        }

                    }

                }
            }
            closedList.add(index);
            
        }

        if (grid[Bi][Bj].parent != null) {
            Cell p = grid[Bi][Bj].parent;
            StdDraw.setPenColor(Color.green);
            while (p.parent != null) {
                StdDraw.filledSquare(p.j, N - p.i - 1, .5);
                p = p.parent;
            }
        }

    }

    private static List<Cell> neighbours(Cell index, Cell[][] grid) {
        List<Cell> neighbours = new ArrayList();
        int N = grid.length;

        if ((index.i - 1) >= 0 && grid[index.i - 1][index.j].blocked == true) {
            neighbours.add(grid[index.i - 1][index.j]);
        }
        if ((index.i + 1) < N && grid[index.i + 1][index.j].blocked == true) {
            neighbours.add(grid[index.i + 1][index.j]);
        }
        if ((index.j - 1) >= 0 && grid[index.i][index.j - 1].blocked == true) {
            neighbours.add(grid[index.i][index.j - 1]);
        }
        if ((index.j + 1) < N && grid[index.i][index.j + 1].blocked == true) {
            neighbours.add(grid[index.i][index.j + 1]);
        }

        return neighbours;
    }

}
