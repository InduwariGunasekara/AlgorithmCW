/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Sachin Tharindu De Zoysa
 */
public class Cell {
    int i ;
    int j;
    boolean blocked;
    int gcost;
    int hcost ;
    Cell parent;
    
    public int getFCost(){
        return hcost+gcost;
    }
    
}
