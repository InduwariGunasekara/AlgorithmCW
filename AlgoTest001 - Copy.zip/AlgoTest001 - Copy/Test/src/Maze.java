
public class Maze {

}
