
public class NPC {

}
