import java.util.Scanner;

/*************************************************************************
 *  Author: Dr E Kapetanios
 *  Last update: 22-02-2017
 *
 *************************************************************************/

public class PathFindingOnSquaredGrid {

    // given an N-by-N matrix of open cells, return an N-by-N matrix
    // of cells reachable from the top
    public static boolean[][] flow(boolean[][] open) {
        int N = open.length;
    
        boolean[][] full = new boolean[N][N];
        for (int j = 0; j < N; j++) {
            flow(open, full, 0, j);
        }
    	
        return full;
    }
    
    // determine set of open/blocked cells using depth first search
    public static void flow(boolean[][] open, boolean[][] full, int i, int j) {
        int N = open.length;

        // base cases
        if (i < 0 || i >= N) return;    // invalid row
        if (j < 0 || j >= N) return;    // invalid column
        if (!open[i][j]) return;        // not an open cell
        if (full[i][j]) return;         // already marked as open

        full[i][j] = true;

        flow(open, full, i+1, j);   // down
        flow(open, full, i, j+1);   // right
        flow(open, full, i, j-1);   // left
        flow(open, full, i-1, j);   // up
    }

    // does the system percolate?
    public static boolean percolates(boolean[][] open) {
        int N = open.length;
    	
        boolean[][] full = flow(open);
        for (int j = 0; j < N; j++) {
            if (full[N-1][j]) return true;
        }
    	
        return false;
    }
    
 // does the system percolate vertically in a direct way?
    public static boolean percolatesDirect(boolean[][] open) {
        int N = open.length;
    	
        boolean[][] full = flow(open);
        int directPerc = 0;
        for (int j = 0; j < N; j++) {
        	if (full[N-1][j]) {
        		// StdOut.println("Hello");
        		directPerc = 1;
        		int rowabove = N-2;
        		for (int i = rowabove; i >= 0; i--) {
        			if (full[i][j]) {
        				// StdOut.println("i: " + i + " j: " + j + " " + full[i][j]);
        				directPerc++;
        			}
        			else break;
        		}
        	}
        }
    	
        // StdOut.println("Direct Percolation is: " + directPerc);
        if (directPerc == N) return true; 
        else return false;
    }
    
    // draw the N-by-N boolean matrix to standard draw
    public static void show(boolean[][] a, boolean which) {
        int N = a.length;
        StdDraw.setXscale(-1, N);;
        StdDraw.setYscale(-1, N);
        StdDraw.setPenColor(StdDraw.BLACK);
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
                if (a[i][j] == which)
                	StdDraw.square(j, N-i-1, .5);
                else StdDraw.filledSquare(j, N-i-1, .5);
    }
    public static int G;

    // wrapper for flow_depthR
    public static int[][] flow_depthR(boolean[][] open, int[] ii, int[] jj) {
        int N = open.length;
        int[][] full = new int[N][N];

        for (int j = 0; j < N; j++) 
            flow_depthR(open, full, 0, j, ii, jj);

        return full;
    }

    // wrapper for flow_depthR
    public static int[][] flow_depthR(boolean[][] open) {
        int N = open.length;
        int[][] full = new int[N][N];
	int[] ii = new int[N*N];
	int[] jj = new int[N*N];

        for (int j = 0; j < N; j++) 
            flow_depthR(open, full, 0, j, ii, jj);

        return full;
    }

    // given an N-by-N matrix of open sites, return an N-by-N matrix
    // of sites reachable from the top
    public static void flow_depthR(boolean[][] open, int[][] full,
				      int[] ii, int[] jj) {
        int N = open.length;

        for (int j = 0; j < N; j++) 
            flow_depthR(open, full, 0, j, ii, jj);

    }

    // determine set of full sites using depth first search
    public static void flow_depthR(boolean[][] open, int[][] full,
				   int i, int j, int[] ii, int[] jj) {
        int N = open.length;

        // base cases
        if (i < 0 || i >= N) return;    // invalid row
        if (j < 0 || j >= N) return;    // invalid column
        if (!open[i][j]) return;        // not an open site
        if (full[i][j] > 0) return;     // already marked as full

	// mark i-j as full
	ii[G] = i;
	jj[G] = j;
	full[i][j] = ++G;

        flow_depthR(open, full, i+1, j, ii, jj);   // down
        flow_depthR(open, full, i, j+1, ii, jj);   // right
        flow_depthR(open, full, i, j-1, ii, jj);   // left
        flow_depthR(open, full, i-1, j, ii, jj);   // up
    }

    // wrapper for flow_depthS
    public static int[][] flow_depthS(boolean[][] open, int[] ii, int[] jj) {
        int N = open.length;
        int[][] full = new int[N][N];

	flow_depthS(open, full, ii, jj);

        return full;
    }

    // wrapper for flow_depthS
    public static int[][] flow_depthS(boolean[][] open) {
        int N = open.length;
        int[][] full = new int[N][N];
	int[] ii = new int[N*N];
	int[] jj = new int[N*N];

	flow_depthS(open, full, ii, jj);

        return full;
    }

    // given an N-by-N matrix of open sites, return an N-by-N matrix
    // of sites reachable from the top.  Uses stack instead of recursion 
    public static void flow_depthS(boolean[][] open, int[][] full,
				      int[] ii, int[] jj) {
        int N = open.length;
	int top = -1;
	int NN = 4*N*N;
	int[] qi = new int[NN];
	int[] qj = new int[NN];

        for (int j = N-1; j >= 0; j--) {
	    qi[++top] = 0;
	    qj[top] = j;
	}

	while (top >= 0) {
	    int i = qi[top];
	    int j = qj[top--];

	    if (i < 0 || i >= N) continue;    // invalid row
	    if (j < 0 || j >= N) continue;    // invalid column
	    if (!open[i][j]) continue;        // not an open site
	    if (full[i][j] > 0) continue;     // already marked as full

	    // mark i-j as full
	    ii[G] = i;
	    jj[G] = j;
	    full[i][j] = ++G;

	    qi[++top] = i-1; qj[top] = j; // up
	    qi[++top] = i; qj[top] = j-1; // left
	    qi[++top] = i; qj[top] = j+1; // right
	    qi[++top] = i+1; qj[top] = j; // down
	}
    }
    // draw the N-by-N boolean matrix to standard draw, including the points A (x1, y1) and B (x2,y2) to be marked by a circle
    public static void show(boolean[][] a, boolean which, int x1, int y1, int x2, int y2) {
        int N = a.length;
        StdDraw.setXscale(-1, N);;
        StdDraw.setYscale(-1, N);
        StdDraw.setPenColor(StdDraw.BLACK);
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
                if (a[i][j] == which)
                	if ((i == x1 && j == y1) ||(i == x2 && j == y2)) {
                		StdDraw.circle(j, N-i-1, .5);
                	}
                	else StdDraw.square(j, N-i-1, .5);
                else StdDraw.filledSquare(j, N-i-1, .5);
    }
    
    // return a random N-by-N boolean matrix, where each entry iC:\Program Files\Java\jdk1.8.0_101\bins
    // true with probability p
    public static boolean[][] random(int N, double p) {
        boolean[][] a = new boolean[N][N];
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
                a[i][j] = StdRandom.bernoulli(p);
        return a;
    }
    /**
     * Gets the Euclidean distance between two points.
     * @param x1 X1 axis coordinate.
     * @param y1 Y1 axis coordinate.
     * @param x2 X2 axis coordinate.
     * @param y2 Y2 axis coordinate.
     * @return The Euclidean distance between x and y.
     */
    public static double Euclidean(int x1, int y1, int x2, int y2){
        double dx = Math.abs(x1 - x2);
        double dy = Math.abs(y1 - y2);
        System.out.println("Answer Euclidean: "+Math.sqrt(dx*dx + dy*dy));
        return Math.sqrt(dx*dx + dy*dy);
    }
    
    public static double Manhattan(int x1, int y1, int x2, int y2){
        double dx = Math.abs(x1 - x2);
        double dy = Math.abs(y1 - y2);
        System.out.println("Answer Manhattan : "+Math.sqrt(dx*dx + dy*dy));
        return Math.sqrt(dx*dx + dy*dy);
    }
    
    public static double Manhattan(double[] i, double[] j){
        double sum = 0;
        for (int a = 0; a < i.length; a++) {
            sum += Math.abs(i[a] - j[a]);
        }
        return sum;
    }
    
    /**
     * Gets the Manhattan distance between two points.
     * @param x1 X1 axis coordinate.
     * @param y1 Y1 axis coordinate.
     * @param x2 X2 axis coordinate.
     * @param y2 Y2 axis coordinate.
     * @return The Manhattan distance between x and y.
     */
    public static double Manhattan(double x1, double y1, double x2, double y2){
        double dx = Math.abs(x1 - x2);
        double dy = Math.abs(y1 - y2);
        System.out.println("Answer Manhattan : "+Math.sqrt(dx*dx + dy*dy));
        return dx + dy;
    }
    /**
	 * Gets the Manhattan distance between two points.
	 * @param x1 X1 axis coordinate.
	 * @param y1 Y1 axis coordinate.
	 * @param x2 X2 axis coordinate.
	 * @param y2 Y2 axis coordinate.
	 * @return The Manhattan distance between x and y.
	 */


	public static double Chebyshev(double[] i, double[] j){
        double max = Math.abs(i[0] - j[0]);
        
        for (int a = 1; a < i.length; a++){
            double abs = Math.abs(i[a] - j[a]);
            if (abs > max) max = abs;
        }
        
        return max;
    }
    
    /**
     * Gets the Chebyshev distance between two points.
     * @param x1 X1 axis coordinate.
     * @param y1 Y1 axis coordinate.
     * @param x2 X2 axis coordinate.
     * @param y2 Y2 axis coordinate.
     * @return The Chebyshev distance between x and y.
     */
    public static double Chebyshev(double x1, double y1, double x2, double y2){
        double max = Math.max(Math.abs(x1 - x2),Math.abs(y1 - y2));
        return max;
    }

    // test client
    public static void main(String[] args) {
        // boolean[][] open = StdArrayIO.readBoolean2D();
    	
    	// The following will generate a 10x10 squared grid with relatively few obstacles in it
    	// The lower the second parameter, the more obstacles (black cells) are generated
    	boolean[][] randomlyGenMatrix = random(10, 0.44);
    	
    	StdArrayIO.print(randomlyGenMatrix);
    	show(randomlyGenMatrix, true);
    	
    	System.out.println();
    	System.out.println("The system percolates: " + percolates(randomlyGenMatrix));
    	
    	System.out.println();
    	System.out.println("The system percolates directly: " + percolatesDirect(randomlyGenMatrix));
    	System.out.println();
    	
    	// Reading the coordinates for points A and B on the input squared grid.
    	
    	// THIS IS AN EXAMPLE ONLY ON HOW TO USE THE JAVA INTERNAL WATCH
    	// Start the clock ticking in order to capture the time being spent on inputting the coordinates
    	// You should position this command accordingly in order to perform the algorithmic analysis
    	Stopwatch timerFlow = new Stopwatch();
    	
    	Scanner in = new Scanner(System.in);
        System.out.println("Enter i for A > ");
        int Ai = in.nextInt();
        
        System.out.println("Enter j for A > ");
        int Aj = in.nextInt();
        
        System.out.println("Enter i for B > ");
        int Bi = in.nextInt();
        
        System.out.println("Enter j for B > ");
        int Bj = in.nextInt();
        
     // THIS IS AN EXAMPLE ONLY ON HOW TO USE THE JAVA INTERNAL WATCH
        // Stop the clock ticking in order to capture the time being spent on inputting the coordinates
    	// You should position this command accordingly in order to perform the algorithmic analysis
    	StdOut.println("Elapsed time = " + timerFlow.elapsedTime());
        
        // System.out.println("Coordinates for A: [" + Ai + "," + Aj + "]");
        // System.out.println("Coordinates for B: [" + Bi + "," + Bj + "]");
        
        show(randomlyGenMatrix, true, Ai, Aj, Bi, Bj);
        Euclidean(Ai, Aj, Bi, Bj);
        
    }

}


